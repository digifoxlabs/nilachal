<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class MyConfig extends BaseConfig
{

  public $gst = '12'  ;
  public $mydiscount = '500'  ;


}


?>