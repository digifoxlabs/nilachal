<html>

<head>
    <title>Nilachal OTP</title>
</head>

<body>
    <h3>Login OTP</h3>
    <p>
    <?= $otp; ?> is a the OTP to login at Nilachal Stay and Tour.
    </p>
    <p>
        Thanks,<br />Nilachal Stay and Tour
    </p>
</body>

</html>