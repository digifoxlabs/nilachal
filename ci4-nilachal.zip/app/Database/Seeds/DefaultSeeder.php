<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DefaultSeeder extends Seeder
{
    public function run()
    {
        
        //Default User 
        $data = [
            'password' => password_hash("password", PASSWORD_DEFAULT),
            'name' => 'ADMIN',
            'mobile' => '9999999999',
            'email'    => 'admin@gmail.com',
            'gender'    => 'male',
            'dob' => '2022-01-01',
            'address' => NULL,
            'district' => NULL,
            'user_type' => 'admin',
            'created_by' => 1,
            'status' => 1,

        ];       
        
        $u_id= $this->db->table('users')->insert($data);

        //Admin permissions
        $gdata = [
                
                 'group_name' => 'superadmin',
                'permissions' => 'a:4:{i:0;s:9:"createAll";i:1;s:7:"viewAll";i:2;s:9:"updateAll";i:3;s:9:"deleteAll";}',             
    
        ];        
        $g_id = $this->db->table('groups')->insert($gdata);


        //Map Default user-group
        $ugdata = [
            'u_id'=> $u_id,
            'g_id' => $g_id,
        ];
        $this->db->table('user_group')->insert($ugdata);



        //Default Site Title
        $sdata = [
            [
                'key'=> 'site_title',
                'value' => 'MY APP',
            ],
            [
                'key'=> 'site_footer',
                'value' => 'Copyright © 2022',

            ] ,                  
            [
                'key'=> 'gst',
                'value' => '18',

            ] ,                  
            [
                'key'=> 'discount',
                'value' => '500',

            ] ,                  
            [
                'key'=> 'currency',
                'value' => 'Rs.',

            ] ,                  
            [
                'key'=> 'admin_email',
                'value' => 'support@nilachalstay.com',

            ] ,                  
            [
                'key'=> 'admin_mobile',
                'value' => '123456789',

            ] ,                  
        ];
        $this->db->table('settings')->insertbatch($sdata);



        //Default Room category
        $roomdata = [
            [ 
                'category'=>'Deluxe',
                'occupancy'=> '2',
                'description'=> 'This is an deluxe room with double occupancy',
                'rate'=> '2500',
                'image'=> 'deluxe.jpg',
                'status'=> 1,              
            ],
            [ 
                'category'=>'Deluxe',
                'occupancy'=> '3',
                'description'=> 'This is an deluxe room with triple occupancy',
                'rate'=> '3000',
                'image'=> 'deluxe.jpg',
                'status'=> 1,              
            ],
            [ 
                'category'=>'Deluxe',
                'occupancy'=> '4',
                'description'=> 'This is an deluxe room wth quad occupancy',
                'rate'=> '3500',
                'image'=> 'deluxe.jpg',
                'status'=> 1,              
            ],
            [ 
                'category'=>'Semi-Deluxe',
                'occupancy'=> '2',
                'description'=> 'This is an deluxe room with double ocupance',
                'rate'=> '1000',
                'image'=> 'semi-deluxe.jpg',
                'status'=> 1,              
            ],
            [ 
                'category'=>'Semi-Deluxe',
                'occupancy'=> '3',
                'description'=> 'This is an deluxe room with triple occupancy',
                'rate'=> '1500',
                'image'=> 'semi-deluxe.jpg',
                'status'=> 1,              
            ],
            [ 
                'category'=>'Semi-Deluxe',
                'occupancy'=> '4',
                'description'=> 'This is an deluxe room with quad occupancy',
                'rate'=> '2000',
                'image'=> 'semi-deluxe.jpg',
                'status'=> 1,              
            ]

        ];
        $this->db->table('room_category')->insertbatch($roomdata);



    }
}
